/* SIGMA-P trip planner for Dasmariñas, Cavite.
   NOTE: places, links, times and fares below are SAMPLE data. Replace NODES and EDGES
   with real stops, jeepney/tricycle/UV routes, travel times and LTFRB or local fares. */

const STUDENT_DISCOUNT = 0.2;   // student fare = base fare less 20%
const BOARDING_PENALTY = 4;     // comfort cost added for every ride you board
const MODES = {
  jeep:  { name: 'Jeepney',    color: '#9b3fd1', comfort: 1.6 },
  trike: { name: 'Tricycle',   color: '#2b5fd9', comfort: 2.0 },
  uv:    { name: 'UV Express', color: '#e8b800', comfort: 1.0 }
};

/* id: [full name, short map label, map x, map y, other names people may type] */
const NODES = {
  sigma:     ['Sigma Street', 'Sigma St.', 60, 400, []],
  p76:       ['76th Street', '76th St.', 120, 340, ['76 st']],
  hci:       ['HCI Yam', 'HCI Yam', 180, 300, ['HCI']],
  a67:       ['67 Avenue', '67 Ave.', 300, 225, ['67 avenue']],
  salitran:  ['Salitran', 'Salitran', 70, 265, []],
  cityhall:  ['Dasmariñas City Hall', 'City Hall', 150, 215, ['City Hall']],
  district:  ['District Dasmariñas', 'District', 225, 250, ['District']],
  sm:        ['SM Dasmariñas Main Entrance', 'SM Dasma', 245, 365, ['SM City Dasmariñas', 'SM']],
  robinsons: ['Robinsons Place Dasmariñas', 'Robinsons', 270, 415, ['Robinsons']],
  dlsu:      ['De La Salle Dasmariñas Gate 1', 'DLSU-D', 335, 300, ['DLSU Dasma, 4103', 'DLSU Dasma', 'DLSU-D', 'DLSU', 'De La Salle']],
  paliparan: ['Paliparan', 'Paliparan', 350, 395, []]
};

/* [from, to, mode, km, minutes, base fare in pesos] – roads work both ways */
const EDGES = [
  ['sigma', 'p76', 'jeep', 1.4, 5, 13],      ['p76', 'hci', 'trike', 1.8, 7, 20],
  ['hci', 'a67', 'jeep', 2.2, 6, 15],        ['sigma', 'salitran', 'trike', 1.6, 6, 20],
  ['salitran', 'cityhall', 'jeep', 2.4, 9, 13], ['p76', 'cityhall', 'jeep', 2.1, 8, 13],
  ['cityhall', 'district', 'jeep', 1.9, 7, 13], ['hci', 'district', 'trike', 1.5, 6, 20],
  ['district', 'a67', 'jeep', 2.0, 6, 13],   ['hci', 'sm', 'jeep', 2.3, 8, 13],
  ['sm', 'robinsons', 'trike', 1.3, 5, 20],  ['sm', 'dlsu', 'uv', 3.6, 11, 25],
  ['district', 'dlsu', 'jeep', 3.0, 10, 15], ['a67', 'dlsu', 'jeep', 2.8, 9, 13],
  ['robinsons', 'paliparan', 'uv', 5.2, 16, 35], ['dlsu', 'paliparan', 'uv', 3.9, 12, 28],
  ['sm', 'district', 'jeep', 2.6, 9, 13]
];

/* What "best" means for each priority button. Each returns the cost of one leg. */
const WEIGHTS = {
  time:     e => e.min,
  budget:   e => e.fare + e.min / 1000,                       // cheapest, then fastest
  comfort:  e => e.min * MODES[e.mode].comfort + BOARDING_PENALTY,
  distance: e => e.km
};

const ADJ = {};
Object.keys(NODES).forEach(id => ADJ[id] = []);
EDGES.forEach(([a, b, mode, km, min, fare]) => {
  ADJ[a].push({ to: b, mode, km, min, fare });
  ADJ[b].push({ to: a, mode, km, min, fare });
});

/* Binary min-heap used as Dijkstra's priority queue */
class Heap {
  constructor() { this.a = []; }
  get size() { return this.a.length; }
  push(k, v) {
    const a = this.a; a.push([k, v]);
    let i = a.length - 1;
    while (i) { const p = (i - 1) >> 1; if (a[p][0] <= a[i][0]) break; [a[p], a[i]] = [a[i], a[p]]; i = p; }
  }
  pop() {
    const a = this.a, top = a[0], last = a.pop();
    if (a.length) {
      a[0] = last; let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = l + 1; let m = i;
        if (l < a.length && a[l][0] < a[m][0]) m = l;
        if (r < a.length && a[r][0] < a[m][0]) m = r;
        if (m === i) break;
        [a[m], a[i]] = [a[i], a[m]]; i = m;
      }
    }
    return top;
  }
}

/* Dijkstra's algorithm: cheapest cost from src to every place, plus the way back (prev). */
function dijkstra(src, weight) {
  const dist = {}, prev = {}, heap = new Heap();
  Object.keys(NODES).forEach(id => dist[id] = Infinity);
  dist[src] = 0; heap.push(0, src);
  while (heap.size) {
    const [d, u] = heap.pop();
    if (d > dist[u]) continue;                       // stale queue entry
    for (const e of ADJ[u]) {
      const nd = d + weight(e);
      if (nd < dist[e.to]) { dist[e.to] = nd; prev[e.to] = { from: u, edge: e }; heap.push(nd, e.to); }
    }
  }
  return { dist, prev };
}

/* Walk prev back from dst to src and return the legs in travel order (null if unreachable). */
function pathTo(prev, src, dst) {
  const legs = []; let c = dst;
  while (c !== src) {
    const p = prev[c]; if (!p) return null;
    legs.unshift({ ...p.edge, from: p.from, to: c }); c = p.from;
  }
  return legs;
}

const norm = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
const names = id => [NODES[id][0], ...NODES[id][4]].map(norm);
/* null = field empty, undefined = no match */
function resolve(text) {
  const q = norm(text); if (!q) return null;
  const ids = Object.keys(NODES);
  return ids.find(id => names(id).includes(q)) || ids.find(id => names(id).some(n => n.includes(q)));
}

/* ---- UI ---- */
const $ = s => document.querySelector(s), app = $('.app'), V = ['onboard', 'home', 'location', 'route'];
const state = { prio: 'time', planned: false };
const cards = [['dlsu', 'Saved', 'a'], ['sm', 'Saved', 'b'], ['district', 'Recommended', 'c']];
const kmFromSigma = dijkstra('sigma', WEIGHTS.distance).dist;
const money = n => { n = Math.round(n * 100) / 100; return Number.isInteger(n) ? n : n.toFixed(2); };
const studentFare = e => e.fare * (1 - STUDENT_DISCOUNT);

function drawCards(q = '') {
  const k = norm(q);
  const r = cards.filter(c => !k || names(c[0]).some(n => n.includes(k)));
  $('#list').innerHTML = r.map(([id, tag, cls]) => `<article class="card"><div class="ct"><h3>${NODES[id][0]}</h3><small>${tag}</small><b class="km">${kmFromSigma[id].toFixed(1)} Km</b><button class="btn sm" data-go="location" data-to="${NODES[id][0]}">Directions</button></div><div class="ph ${cls}" role="img" aria-label="${NODES[id][0]}"></div></article>`).join('')
    || '<p class="none">No places match your search. Try another name.</p>';
}

function drawMap(legs, src, dst) {
  const on = new Set(legs.flatMap(l => [l.from, l.to])), P = id => NODES[id];
  let s = EDGES.map(([a, b]) => `<line class="edge" x1="${P(a)[2]}" y1="${P(a)[3]}" x2="${P(b)[2]}" y2="${P(b)[3]}"/>`).join('');
  s += legs.map(l => `<line x1="${P(l.from)[2]}" y1="${P(l.from)[3]}" x2="${P(l.to)[2]}" y2="${P(l.to)[3]}" stroke="${MODES[l.mode].color}" stroke-width="5" stroke-linecap="round"/>`).join('');
  for (const id in NODES) {
    const [, short, x, y] = NODES[id], hit = on.has(id);
    const fill = id === src ? '#a0522d' : id === dst ? '#1d6b3a' : hit ? '#fff' : 'var(--mut)';
    s += `<circle cx="${x}" cy="${y}" r="${hit ? 7 : 3}" fill="${fill}" stroke="${hit ? '#fff' : 'none'}" stroke-width="2"/>`;
    if (hit) s += `<text class="lbl" x="${x > 270 ? x - 11 : x + 11}" y="${y - 9}" text-anchor="${x > 270 ? 'end' : 'start'}">${short}</text>`;
  }
  $('#rg').innerHTML = s;
}

function render(legs, src, dst) {
  $('#rf').textContent = NODES[src][0]; $('#rd').textContent = NODES[dst][0];
  $('#legs').innerHTML = legs.map(l => `<div class="leg"><b>₱${money(studentFare(l))}</b><svg class="i"><use href="#i-bus"/></svg><span>${NODES[l.from][0]} - ${NODES[l.to][0]}<small>${MODES[l.mode].name} · ${l.km} km</small></span><span>${l.min}m</span><i class="dot" style="background:${MODES[l.mode].color}" title="${MODES[l.mode].name}"></i></div>`).join('');
  $('#chips').innerHTML = legs.map(l => `<span>${NODES[l.from][1]} - ${NODES[l.to][1]}</span>`).join('');
  $('#tt').textContent = legs.reduce((t, l) => t + l.min, 0) + 'min';
  $('#tf').textContent = money(legs.reduce((t, l) => t + studentFare(l), 0)) + ' Pesos';
  $('#td').textContent = legs.reduce((t, l) => t + l.km, 0).toFixed(1) + ' km';
  drawMap(legs, src, dst); state.planned = true;
}

function showErr(msg) { const e = $('#err'); e.textContent = msg; e.hidden = !msg; return false; }

/* strict = user pressed Search (report problems); otherwise fall back to the sample trip */
function plan(strict) {
  const f = resolve($('#from').value), t = resolve($('#to').value);
  if (strict) {
    const bad = f === undefined ? $('#from').value : t === undefined ? $('#to').value : null;
    if (bad) return showErr(`We couldn’t find “${bad.trim()}”. Pick a place from the list.`);
  }
  let src = f || 'sigma', dst = t || 'a67';
  if (src === dst) { if (strict) return showErr('Choose two different places.'); src = 'sigma'; dst = 'a67'; }
  const legs = pathTo(dijkstra(src, WEIGHTS[state.prio]).prev, src, dst);
  if (!legs) return showErr('No route found between those places.');
  showErr(''); render(legs, src, dst); return true;
}

function go() {
  const v = location.hash.slice(1);
  app.dataset.v = V.includes(v) ? v : 'onboard';
  if (app.dataset.v === 'route' && !state.planned) plan(false);
  scrollTo(0, 0);
  document.querySelectorAll('[data-nav]').forEach(a => a.classList.toggle('on', a.dataset.nav === app.dataset.v));
}

$('#places').innerHTML = Object.values(NODES).map(n => `<option value="${n[0]}">`).join('');
drawCards();
$('#q').addEventListener('input', e => drawCards(e.target.value));
addEventListener('hashchange', go); go();

document.addEventListener('click', e => {
  const t = e.target.closest('[data-go]'); if (!t) return;
  if (t.dataset.to) $('#to').value = t.dataset.to;
  if (t.dataset.go === 'route' && !plan(true)) return;
  location.hash = t.dataset.go;
});
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.closest('.fld')) $('#location [data-go=route]').click();
});
$('#pri').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  state.prio = b.textContent.trim().toLowerCase();
  document.querySelectorAll('#pri button').forEach(x => x.setAttribute('aria-pressed', x === b));
});
